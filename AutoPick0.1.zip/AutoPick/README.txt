AUTOPICK v2 - Rapido Captain auto-accept (Android app)

APK BANANE KA TAREEKA (GitHub, sabse aasaan):
 1. GitHub repo me ye AutoPick.zip upload karo (zip ko extract mat karo).
 2. Repo me .github/workflows/build.yml hona chahiye (alag file di gayi hai).
 3. Actions tab me build hara hone ka wait karo, Releases se app-debug.apk download karo.
 4. Is version me fixed signing key hai: aage ki APK purani app ke upar seedha update ho jayegi.
    (Sirf pehli baar, purani/alag-key wali app ho to uninstall karna padega.)

APP SETUP:
 - Pehli baar kholne pe Notification, Battery popup aur Accessibility settings apne aap aayengi.
 - Accessibility me AutoPick ON karo. 'Restricted setting' aaye to App Info -> teen dot -> Allow restricted settings.
 - DEBUG -> Screen dump mode ON -> Rapido me ride card aane do -> DUMP COPY KARO -> chat me bhejo.
