plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.autopick"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.autopick"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    // Fixed signing key: har build same key se sign hoga,
    // isliye nayi APK purani app ke upar seedha update ho jayegi (uninstall nahi karna padega).
    signingConfigs {
        create("autopick") {
            storeFile = file("autopick.jks")
            storePassword = "autopick123"
            keyAlias = "autopick"
            keyPassword = "autopick123"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("autopick") }
        getByName("release") { signingConfig = signingConfigs.getByName("autopick") }
    }

    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
}
