package com.autopick

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*

/** Saari settings. UI aur service dono yahin se padhte hain. */
object Cfg {
    private var sp: SharedPreferences? = null

    // ----- filters -----
    var enabled by mutableStateOf(false)
    var minDrop by mutableFloatStateOf(15f)     // drop distance is se kam ho to skip
    var maxPickup by mutableFloatStateOf(3f)    // pickup distance is se zyada ho to skip
    var minFare by mutableFloatStateOf(0f)      // total fare (base + bonus)
    var minPerKm by mutableFloatStateOf(0f)     // Rs per km (pickup + drop)
    var allowParcel by mutableStateOf(true)

    // ----- options -----
    var bubble by mutableStateOf(true)          // floating ON/OFF button
    var buzz by mutableStateOf(true)            // ride pakadne pe vibrate
    var notify by mutableStateOf(true)          // ride pakadne pe notification
    var dump by mutableStateOf(false)           // debug: screen tree dump

    // ----- first-run flow flags -----
    var askedNotif = false
    var askedBat = false
    var askedAcc = false
    var notifDialogShown = false

    @Volatile var lastDump: String = ""
    @Volatile var hasAcceptDump: Boolean = false

    fun init(c: Context) {
        if (sp != null) return
        val s = c.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        sp = s
        enabled = s.getBoolean("enabled", false)
        minDrop = s.getFloat("minDrop", 15f)
        maxPickup = s.getFloat("maxPickup", 3f)
        minFare = s.getFloat("minFare", 0f)
        minPerKm = s.getFloat("minPerKm", 0f)
        allowParcel = s.getBoolean("allowParcel", true)
        bubble = s.getBoolean("bubble", true)
        buzz = s.getBoolean("buzz", true)
        notify = s.getBoolean("notify", true)
        dump = s.getBoolean("dump", false)
        askedNotif = s.getBoolean("askedNotif", false)
        askedBat = s.getBoolean("askedBat", false)
        askedAcc = s.getBoolean("askedAcc", false)
        notifDialogShown = s.getBoolean("notifDialogShown", false)
    }

    fun save() {
        sp?.edit()
            ?.putBoolean("enabled", enabled)
            ?.putFloat("minDrop", minDrop)
            ?.putFloat("maxPickup", maxPickup)
            ?.putFloat("minFare", minFare)
            ?.putFloat("minPerKm", minPerKm)
            ?.putBoolean("allowParcel", allowParcel)
            ?.putBoolean("bubble", bubble)
            ?.putBoolean("buzz", buzz)
            ?.putBoolean("notify", notify)
            ?.putBoolean("dump", dump)
            ?.putBoolean("askedNotif", askedNotif)
            ?.putBoolean("askedBat", askedBat)
            ?.putBoolean("askedAcc", askedAcc)
            ?.putBoolean("notifDialogShown", notifDialogShown)
            ?.apply()
    }
}

object Stats {
    var nAcc by mutableIntStateOf(0)
    var nSkip by mutableIntStateOf(0)
    val lines = mutableStateListOf<String>()
    private val main = Handler(Looper.getMainLooper())

    /** kind: 'a' accept, 'k' skip, 'i' sirf info */
    fun event(kind: Char, line: String) {
        main.post {
            when (kind) {
                'a' -> nAcc++
                'k' -> nSkip++
                else -> {}
            }
            lines.add(0, line)
            while (lines.size > 80) lines.removeAt(lines.lastIndex)
        }
    }

    fun reset() {
        main.post { nAcc = 0; nSkip = 0; lines.clear() }
    }
}
