package com.autopick

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

/** Saari permission ka status check + settings screens kholne ke helpers. */
object Perms {

    private fun go(c: Context, i: Intent): Boolean = try {
        c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        false
    }

    private fun activityOf(c: Context): Activity? {
        var x: Context? = c
        while (x is ContextWrapper) {
            if (x is Activity) return x
            x = x.baseContext
        }
        return null
    }

    // ---------- status ----------
    fun svcOn(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        return s.contains("${c.packageName}/${PickService::class.java.name}")
    }

    fun batteryOk(c: Context): Boolean =
        c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)

    fun notifOk(c: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return c.getSystemService(NotificationManager::class.java).areNotificationsEnabled()
    }

    // ---------- actions ----------
    fun openAcc(c: Context): Boolean = go(c, Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    fun openAppInfo(c: Context): Boolean =
        go(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${c.packageName}")))

    fun openBattery(c: Context): Boolean {
        if (go(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${c.packageName}")))) return true
        return go(c, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    fun openNotifSettings(c: Context): Boolean =
        go(c, Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName))

    /** Android 13+ pe pehli baar asli popup, uske baad settings screen. */
    fun askNotif(c: Context): Boolean {
        val a = activityOf(c)
        if (Build.VERSION.SDK_INT >= 33 && a != null && !Cfg.notifDialogShown &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            Cfg.notifDialogShown = true
            Cfg.save()
            a.requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 11)
            return true
        }
        return openNotifSettings(c)
    }

    private val oemAutostart = listOf(
        "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
        "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
        "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
        "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
        "com.iqoo.secure" to "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity",
        "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
        "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity",
        "com.oneplus.security" to "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity",
        "com.asus.mobilemanager" to "com.asus.mobilemanager.autostart.AutoStartActivity",
    )

    /** Phone company ki Autostart / Background screen. Na mile to App Info khulta hai. */
    fun openAutostart(c: Context): Boolean {
        for ((pkg, cls) in oemAutostart) {
            if (go(c, Intent().setComponent(ComponentName(pkg, cls)))) return true
        }
        return openAppInfo(c)
    }
}
