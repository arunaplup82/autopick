package com.autopick

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Notification shade se ek tap me ON/OFF, bike chalate waqt app kholne ki zarurat nahi. */
class PickTile : TileService() {
    override fun onStartListening() {
        Cfg.init(this)
        refresh()
    }

    override fun onClick() {
        Cfg.init(this)
        Cfg.enabled = !Cfg.enabled
        Cfg.save()
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (Cfg.enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (Cfg.enabled) "AutoPick ON" else "AutoPick OFF"
        t.updateTile()
    }
}
