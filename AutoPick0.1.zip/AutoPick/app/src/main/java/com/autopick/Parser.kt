package com.autopick

data class Ride(
    val fare: Float,
    val bonus: Float,
    val pickupKm: Float,
    val dropKm: Float,
    val parcel: Boolean,
) {
    val total: Float get() = fare + bonus
    val perKm: Float get() = total / (pickupKm + dropKm).coerceAtLeast(0.1f)
    val key: String get() = "$fare|$bonus|$pickupKm|$dropKm"
}

object RideParser {
    private val km = Regex("""(\d+(?:\.\d+)?)\s*km""", RegexOption.IGNORE_CASE)
    private val rs = Regex("""₹\s*(\d+(?:\.\d+)?)""")
    private val plus = Regex("""\+\s*₹\s*(\d+(?:\.\d+)?)""")

    /**
     * Card ka text: pehla km = pickup, doosra km = drop.
     * Pehla ₹ = fare, "+₹x" = bonus.
     */
    fun parse(t: String): Ride? {
        val k = km.findAll(t).map { it.groupValues[1].toFloat() }.toList()
        if (k.size < 2) return null
        val f = rs.find(t) ?: return null
        val b = plus.find(t)?.groupValues?.get(1)?.toFloat() ?: 0f
        return Ride(f.groupValues[1].toFloat(), b, k[0], k[1], t.contains("parcel", true))
    }
}

object Rules {
    /** null = accept karo. Warna skip ki wajah. */
    fun decide(r: Ride): String? = when {
        r.pickupKm > Cfg.maxPickup -> "pickup %.1f > %.1f".format(r.pickupKm, Cfg.maxPickup)
        r.dropKm < Cfg.minDrop -> "drop %.1f < %.1f".format(r.dropKm, Cfg.minDrop)
        r.total < Cfg.minFare -> "fare ${r.total.toInt()} < ${Cfg.minFare.toInt()}"
        r.perKm < Cfg.minPerKm -> "%.1f/km < %.1f".format(r.perKm, Cfg.minPerKm)
        r.parcel && !Cfg.allowParcel -> "parcel off"
        else -> null
    }
}
