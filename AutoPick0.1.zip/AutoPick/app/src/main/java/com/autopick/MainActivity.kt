package com.autopick

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val BG = Color(0xFF0A0A0A)
private val CARD = Color(0xFF161616)
private val NEON = Color(0xFF00FF9C)
private val RED = Color(0xFFFF4D4D)
private val AMBER = Color(0xFFFFC107)
private val DIM = Color(0xFF8A8A8A)

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        setContent { App() }
    }

    /**
     * Pehli baar app khulte hi permission ka flow apne aap chalta hai:
     * 1) Notification popup  2) Battery popup  3) Accessibility settings.
     * Har step sirf ek baar auto-khulta hai; baad me app ke SETUP card se kabhi bhi kar sakte ho.
     */
    override fun onResume() {
        super.onResume()
        Cfg.init(this)

        if (!Cfg.askedNotif) {
            Cfg.askedNotif = true
            Cfg.save()
            if (!Perms.notifOk(this) && Perms.askNotif(this)) return
        }
        if (!Cfg.askedBat) {
            Cfg.askedBat = true
            Cfg.save()
            if (!Perms.batteryOk(this) && Perms.openBattery(this)) return
        }
        if (!Cfg.askedAcc) {
            Cfg.askedAcc = true
            Cfg.save()
            if (!Perms.svcOn(this)) Perms.openAcc(this)
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var svcOn by remember { mutableStateOf(false) }
    var batOk by remember { mutableStateOf(true) }
    var notifOk by remember { mutableStateOf(true) }
    var expand by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            svcOn = Perms.svcOn(ctx)
            batOk = Perms.batteryOk(ctx)
            notifOk = Perms.notifOk(ctx)
            delay(1000)
        }
    }
    val allOk = svcOn && batOk && notifOk
    val on = Cfg.enabled && svcOn

    MaterialTheme(colorScheme = darkColorScheme(primary = NEON, background = BG, surface = BG)) {
        Surface(Modifier.fillMaxSize(), color = BG) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ---------------- HEADER
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LogoMark(52.dp)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("AUTOPICK", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                            Text("Rapido ride auto-accept", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // ---------------- PERMISSION CENTER
                item {
                    Card2 {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                if (allOk) "✓ PERMISSIONS OK" else "SETUP — PERMISSION ALLOW KARO",
                                color = if (allOk) NEON else AMBER,
                                fontSize = 12.sp, fontWeight = FontWeight.Black,
                                modifier = Modifier.weight(1f)
                            )
                            if (allOk) {
                                TextButton(onClick = { expand = !expand }) {
                                    Text(if (expand) "CHHUPAO" else "DEKHO", color = DIM)
                                }
                            }
                        }
                        if (!allOk || expand) {
                            PermRow("1. Accessibility", "ride pakadne ke liye (sabse zaruri)", svcOn) { Perms.openAcc(ctx) }
                            PermRow("2. Battery unrestricted", "app background me band na ho", batOk) { Perms.openBattery(ctx) }
                            PermRow("3. Notification", "ride pakadne pe alert", notifOk) { Perms.askNotif(ctx) }
                            ManualRow("4. Autostart / Background", "phone ki setting, yahan status nahi dikhta") { Perms.openAutostart(ctx) }
                            if (!svcOn) {
                                Text(
                                    "Accessibility list me AutoPick grey ho ya 'Restricted setting' aaye to: " +
                                        "APP INFO kholo → upar teen dot (⋮) → 'Allow restricted settings' → " +
                                        "fir wapas Accessibility me AutoPick ON karo.",
                                    color = DIM, fontSize = 12.sp
                                )
                                Button(
                                    onClick = { Perms.openAppInfo(ctx) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A2A), contentColor = Color.White)
                                ) { Text("APP INFO KHOLO") }
                            }
                            Text(
                                "Tip: Recent apps me AutoPick ke card ko long-press karke 'Lock' laga do, " +
                                    "taaki phone use band na kare.",
                                color = DIM, fontSize = 12.sp
                            )
                        }
                    }
                }

                // ---------------- POWER BUTTON
                item {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(190.dp).clip(CircleShape)
                                .background(if (on) NEON else CARD)
                                .border(3.dp, if (on) NEON else Color(0xFF333333), CircleShape)
                                .clickable {
                                    if (!svcOn) {
                                        Perms.openAcc(ctx)
                                    } else {
                                        Cfg.enabled = !Cfg.enabled
                                        Cfg.save()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    if (on) "ON" else "OFF", fontSize = 46.sp, fontWeight = FontWeight.Black,
                                    color = if (on) Color.Black else Color.White
                                )
                                Text(
                                    if (!svcOn) "pehle Accessibility allow karo" else if (on) "ride pakad raha hai" else "tap = start",
                                    fontSize = 12.sp, color = if (on) Color.Black else DIM
                                )
                            }
                        }
                    }
                }

                // ---------------- STATS
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatBox("PAKDI", Stats.nAcc.toString(), NEON, Modifier.weight(1f))
                        StatBox("SKIP", Stats.nSkip.toString(), RED, Modifier.weight(1f))
                        StatBox("TOTAL", (Stats.nAcc + Stats.nSkip).toString(), Color.White, Modifier.weight(1f))
                    }
                }

                // ---------------- FILTERS
                item {
                    Card2 {
                        Text("FILTER", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Knob("Min drop distance", Cfg.minDrop, 0f..60f, "km") { Cfg.minDrop = it; Cfg.save() }
                        Knob("Max pickup distance", Cfg.maxPickup, 0.5f..10f, "km") { Cfg.maxPickup = it; Cfg.save() }
                        Knob("Min fare (base + bonus)", Cfg.minFare, 0f..500f, "₹") { Cfg.minFare = it; Cfg.save() }
                        Knob("Min ₹ per km", Cfg.minPerKm, 0f..15f, "₹/km") { Cfg.minPerKm = it; Cfg.save() }
                        SwRow("Parcel rides bhi lo", Cfg.allowParcel) { Cfg.allowParcel = it; Cfg.save() }
                    }
                }

                // ---------------- OPTIONS
                item {
                    Card2 {
                        Text("OPTIONS", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        SwRow("Floating ON/OFF button (Rapido ke upar)", Cfg.bubble) { Cfg.bubble = it; Cfg.save() }
                        SwRow("Ride pakadne pe vibrate", Cfg.buzz) { Cfg.buzz = it; Cfg.save() }
                        SwRow("Ride pakadne pe notification", Cfg.notify) { Cfg.notify = it; Cfg.save() }
                    }
                }

                // ---------------- HOW TO
                item {
                    Card2 {
                        Text("KAISE CHALAYEIN", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Text(
                            "1. Rapido Captain kholo, On Duty + Go To ON karo.\n" +
                                "2. AutoPick ON karo (yahan, floating button se, ya notification tile se).\n" +
                                "3. Filter ke hisaab se ride aate hi apne aap Accept ho jayegi.",
                            color = Color.White, fontSize = 13.sp, lineHeight = 19.sp
                        )
                    }
                }

                // ---------------- DEBUG
                item {
                    Card2 {
                        Text("DEBUG", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Screen dump mode\n(Rapido kholke ride card aane do)", color = Color.White,
                                fontSize = 13.sp, modifier = Modifier.weight(1f)
                            )
                            Switch(Cfg.dump, {
                                Cfg.dump = it
                                if (it) { Cfg.hasAcceptDump = false; Cfg.lastDump = "" }
                                Cfg.save()
                            })
                        }
                        Button(
                            onClick = {
                                val cm = ctx.getSystemService(ClipboardManager::class.java)
                                cm.setPrimaryClip(ClipData.newPlainText("dump", Cfg.lastDump))
                                Toast.makeText(
                                    ctx,
                                    if (Cfg.lastDump.isEmpty()) "Dump khali hai" else "Dump copy ho gaya",
                                    Toast.LENGTH_SHORT
                                ).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NEON, contentColor = Color.Black)
                        ) { Text("DUMP COPY KARO", fontWeight = FontWeight.Black) }
                        TextButton(onClick = { Stats.reset() }) { Text("Log reset", color = DIM) }
                    }
                }

                // ---------------- LIVE LOG
                item { Text("LIVE LOG", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black) }
                items(Stats.lines) {
                    Text(
                        it,
                        color = if (it.startsWith("⚡")) NEON else if (it.startsWith("✗")) RED else DIM,
                        fontFamily = FontFamily.Monospace, fontSize = 12.sp
                    )
                }

                item {
                    Text(
                        "Note: Auto-accept Rapido ke terms ke against ho sakta hai. Account pe restriction ka risk aapka apna hai.",
                        color = DIM, fontSize = 11.sp
                    )
                }
            }
        }
    }
}

// ====================================================================== components

@Composable
fun LogoMark(size: Dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension / 80f
        fun o(x: Float, y: Float) = Offset((x - 14f) * s, (y - 14f) * s)
        drawCircle(color = NEON.copy(alpha = 0.28f), radius = 32f * s, center = o(54f, 54f), style = Stroke(width = 1.5f * s))
        drawCircle(color = NEON, radius = 24f * s, center = o(54f, 54f), style = Stroke(width = 3.5f * s))
        val bolt = Path()
        val a = o(58f, 36f)
        bolt.moveTo(a.x, a.y)
        val pts = listOf(o(44f, 57f), o(53f, 57f), o(50f, 72f), o(65f, 50f), o(56f, 50f))
        for (p in pts) bolt.lineTo(p.x, p.y)
        bolt.close()
        drawPath(bolt, NEON)
    }
}

@Composable
fun Card2(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CARD).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        content = content
    )
}

@Composable
fun StatBox(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(CARD).padding(14.dp)) {
        Text(value, color = color, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text(label, color = DIM, fontSize = 11.sp)
    }
}

@Composable
fun Knob(title: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(title, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("%.1f %s".format(value, unit), color = NEON, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Slider(
            value = value,
            onValueChange = { onChange(Math.round(it * 2f) / 2f) },
            valueRange = range,
            colors = SliderDefaults.colors(thumbColor = NEON, activeTrackColor = NEON)
        )
    }
}

@Composable
fun SwRow(title: String, v: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Switch(v, onChange)
    }
}

@Composable
fun PermRow(title: String, sub: String, ok: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = DIM, fontSize = 11.sp)
        }
        if (ok) {
            Text("✓ DONE", color = NEON, fontWeight = FontWeight.Black, fontSize = 13.sp)
        } else {
            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = NEON, contentColor = Color.Black)
            ) { Text("ALLOW", fontWeight = FontWeight.Black) }
        }
    }
}

@Composable
fun ManualRow(title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = DIM, fontSize = 11.sp)
        }
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A2A), contentColor = Color.White)
        ) { Text("OPEN", fontWeight = FontWeight.Bold) }
    }
}
