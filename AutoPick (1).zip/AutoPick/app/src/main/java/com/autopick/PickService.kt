package com.autopick

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.HandlerThread
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class PickService : AccessibilityService() {

    private lateinit var ht: HandlerThread
    private lateinit var h: Handler
    @Volatile private var pending = false
    private val ui = Handler(Looper.getMainLooper())

    private var lastSkipKey = ""
    private var lastClickKey = ""
    private var lastClickAt = 0L
    private var lastDumpAt = 0L
    private var t0 = 0L

    override fun onServiceConnected() {
        Cfg.init(this)
        ht = HandlerThread("autopick").also { it.start() }
        h = Handler(ht.looper)
        Stats.event('i', "service connected")
        ui.post(tick)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        ui.removeCallbacks(tick)
        bubble?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Throwable) {} }
        bubble = null
        if (::ht.isInitialized) ht.quitSafely()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (!Cfg.enabled && !Cfg.dump) return
        if (e?.packageName?.contains("rapido", true) != true) return
        if (pending) return            // ek scan already queue me hai to naya mat banao
        pending = true
        h.post {
            pending = false
            try { scan() } catch (t: Throwable) { Stats.event('i', "ERR ${t.message}") }
        }
    }

    private fun rapidoRoots(): List<AccessibilityNodeInfo> {
        val r = windows.mapNotNull { it.root }
            .filter { it.packageName?.contains("rapido", true) == true }
        if (r.isNotEmpty()) return r
        return listOfNotNull(rootInActiveWindow)
            .filter { it.packageName?.contains("rapido", true) == true }
    }

    private fun scan() {
        t0 = SystemClock.uptimeMillis()
        for (root in rapidoRoots()) {
            val btns = root.findAccessibilityNodeInfosByText("Accept")
            if (btns.isEmpty()) continue

            if (Cfg.dump && t0 - lastDumpAt > 800) {
                lastDumpAt = t0
                Cfg.lastDump = "pkg=${root.packageName}\n" + dump(root)
            }
            if (!Cfg.enabled) continue

            for (b in btns) {
                if (!b.isVisibleToUser) continue
                val l = label(b).lowercase()
                if (!l.contains("accept") || l.contains("accepted")) continue
                val ride = cardOf(b) ?: continue
                handle(b, ride)
            }
        }
    }

    private fun handle(btn: AccessibilityNodeInfo, r: Ride) {
        val why = Rules.decide(r)
        val now = SystemClock.uptimeMillis()
        val tag = "₹${r.total.toInt()} p%.1f d%.1f".format(r.pickupKm, r.dropKm)

        if (why != null) {
            if (r.key != lastSkipKey) {
                lastSkipKey = r.key
                Stats.event('k', "✗ $tag — $why")
            }
            return
        }
        if (r.key == lastClickKey && now - lastClickAt < 1500) return
        if (label(btn).length > 25) {
            Stats.event('i', "Accept node merged hai — dump copy karke bhejo")
            return
        }
        val ok = click(btn)
        val fresh = r.key != lastClickKey
        lastClickKey = r.key
        lastClickAt = now
        val ms = SystemClock.uptimeMillis() - t0
        if (ok && fresh && Cfg.buzz) buzz()
        Stats.event(if (ok && fresh) 'a' else 'i', if (ok) "⚡ $tag — ${ms}ms" else "✗ click fail $tag")
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var p: AccessibilityNodeInfo? = n
        var i = 0
        while (p != null && i < 4) {
            if (p.isClickable && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            p = p.parent; i++
        }
        // fallback: seedha screen pe tap
        val r = Rect(); n.getBoundsInScreen(r)
        if (r.width() <= 0 || r.height() <= 0) return false
        val path = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 30)).build()
        return dispatchGesture(g, null, null)
    }

    /** Accept button se upar chadho jab tak ek poora ride card (2 km + ₹) na mil jaye. */
    private fun cardOf(btn: AccessibilityNodeInfo): Ride? {
        var p: AccessibilityNodeInfo? = btn
        var d = 0
        while (p != null && d < 8) {
            val sb = StringBuilder()
            collect(p, sb, intArrayOf(250))
            RideParser.parse(sb.toString())?.let { return it }
            p = p.parent; d++
        }
        return null
    }

    private fun label(n: AccessibilityNodeInfo): String {
        val t = n.text?.toString() ?: ""
        val d = n.contentDescription?.toString() ?: ""
        return if (d.isNotEmpty() && d != t) "$t $d".trim() else t
    }

    private fun collect(n: AccessibilityNodeInfo, sb: StringBuilder, left: IntArray) {
        if (left[0]-- <= 0) return
        val l = label(n)
        if (l.isNotEmpty()) sb.append(l).append(' ')
        // merged label me khud hi km-text hai to bacchon ko dubara mat padho
        if (l.contains("km", true)) return
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, sb, left) }
    }

    private fun dump(n: AccessibilityNodeInfo?, d: Int = 0, sb: StringBuilder = StringBuilder()): String {
        if (n == null || sb.length > 20000) return sb.toString()
        val r = Rect(); n.getBoundsInScreen(r)
        val l = label(n)
        if (l.isNotEmpty() || n.isClickable) {
            sb.append("  ".repeat(d))
                .append(n.className?.toString()?.substringAfterLast('.'))
                .append(" [").append(l).append("]")
                .append(if (n.isClickable) " CLICK" else "")
                .append(" id=").append(n.viewIdResourceName)
                .append(' ').append(r.toShortString()).append('\n')
        }
        for (i in 0 until n.childCount) dump(n.getChild(i), d + 1, sb)
        return sb.toString()
    }

    private fun buzz() {
        try {
            getSystemService(Vibrator::class.java)
                .vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Throwable) {}
    }

    // ---------- floating ON/OFF button ----------
    // Accessibility overlay se chalta hai, isliye alag "Display over other apps" permission nahi chahiye.
    private var bubble: TextView? = null
    private var lastOn: Boolean? = null
    private val tick = object : Runnable {
        override fun run() {
            try { syncBubble() } catch (_: Throwable) {}
            ui.postDelayed(this, 700)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun syncBubble() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Cfg.bubble && bubble == null) {
            val lp = WindowManager.LayoutParams(
                dp(56), dp(56),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(220) }

            val tv = TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
            }
            tv.setOnTouchListener(object : View.OnTouchListener {
                var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                        MotionEvent.ACTION_MOVE -> {
                            val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                            if (abs(dx) > 12 || abs(dy) > 12) moved = true
                            if (moved) { lp.x = sx + dx; lp.y = sy + dy; wm.updateViewLayout(v, lp) }
                        }
                        MotionEvent.ACTION_UP -> if (!moved) {
                            Cfg.enabled = !Cfg.enabled; Cfg.save(); lastOn = null; syncBubble()
                        }
                    }
                    return true
                }
            })
            wm.addView(tv, lp)
            bubble = tv
            lastOn = null
        } else if (!Cfg.bubble && bubble != null) {
            wm.removeView(bubble); bubble = null
        }
        bubble?.let { tv ->
            val on = Cfg.enabled
            if (lastOn != on) {
                lastOn = on
                tv.text = if (on) "ON" else "OFF"
                tv.setTextColor(if (on) Color.BLACK else Color.WHITE)
                tv.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (on) 0xFF00FF9C.toInt() else 0xDD222222.toInt())
                }
            }
        }
    }
}
