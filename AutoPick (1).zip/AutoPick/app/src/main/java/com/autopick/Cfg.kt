package com.autopick

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*

/** Saari settings. UI aur service dono yahin se padhte hain. */
object Cfg {
    private var sp: SharedPreferences? = null

    var enabled by mutableStateOf(false)
    var minDrop by mutableFloatStateOf(15f)     // drop distance is se kam ho to skip
    var maxPickup by mutableFloatStateOf(3f)    // pickup distance is se zyada ho to skip
    var minFare by mutableFloatStateOf(0f)      // total fare (base + bonus)
    var minPerKm by mutableFloatStateOf(0f)     // Rs per km (pickup + drop)
    var allowParcel by mutableStateOf(true)
    var dump by mutableStateOf(false)
    var bubble by mutableStateOf(true)          // floating ON/OFF button
    var buzz by mutableStateOf(true)            // ride pakadne pe vibrate
    var askedBat = false
    var askedAcc = false
    @Volatile var lastDump: String = ""

    fun init(c: Context) {
        if (sp != null) return
        val s = c.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
        sp = s
        enabled = s.getBoolean("enabled", false)
        minDrop = s.getFloat("minDrop", 15f)
        maxPickup = s.getFloat("maxPickup", 3f)
        minFare = s.getFloat("minFare", 0f)
        minPerKm = s.getFloat("minPerKm", 0f)
        allowParcel = s.getBoolean("allowParcel", true)
        dump = s.getBoolean("dump", false)
        bubble = s.getBoolean("bubble", true)
        buzz = s.getBoolean("buzz", true)
        askedBat = s.getBoolean("askedBat", false)
        askedAcc = s.getBoolean("askedAcc", false)
    }

    fun save() {
        sp?.edit()
            ?.putBoolean("enabled", enabled)
            ?.putFloat("minDrop", minDrop)
            ?.putFloat("maxPickup", maxPickup)
            ?.putFloat("minFare", minFare)
            ?.putFloat("minPerKm", minPerKm)
            ?.putBoolean("allowParcel", allowParcel)
            ?.putBoolean("dump", dump)
            ?.putBoolean("bubble", bubble)
            ?.putBoolean("buzz", buzz)
            ?.putBoolean("askedBat", askedBat)
            ?.putBoolean("askedAcc", askedAcc)
            ?.apply()
    }
}

object Stats {
    var nAcc by mutableIntStateOf(0)
    var nSkip by mutableIntStateOf(0)
    val lines = mutableStateListOf<String>()
    private val main = Handler(Looper.getMainLooper())

    /** kind: 'a' accept, 'k' skip, 'i' sirf info */
    fun event(kind: Char, line: String) {
        main.post {
            when (kind) { 'a' -> nAcc++; 'k' -> nSkip++ }
            lines.add(0, line)
            while (lines.size > 80) lines.removeAt(lines.lastIndex)
        }
    }

    fun reset() { main.post { nAcc = 0; nSkip = 0; lines.clear() } }
}
