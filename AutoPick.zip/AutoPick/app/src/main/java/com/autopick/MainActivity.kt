package com.autopick

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val BG = Color(0xFF0A0A0A)
private val CARD = Color(0xFF161616)
private val NEON = Color(0xFF00FF9C)
private val RED = Color(0xFFFF4D4D)
private val DIM = Color(0xFF8A8A8A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        setContent { App() }
    }
}

fun isSvcOn(c: Context): Boolean {
    val s = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
        ?: return false
    return s.contains("${c.packageName}/${PickService::class.java.name}")
}

@Composable
fun App() {
    val ctx = LocalContext.current
    var svcOn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { svcOn = isSvcOn(ctx); delay(1000) } }
    val on = Cfg.enabled && svcOn

    MaterialTheme(colorScheme = darkColorScheme(primary = NEON, background = BG, surface = BG)) {
        Surface(Modifier.fillMaxSize(), color = BG) {
            LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text("AUTOPICK", color = NEON, fontSize = 13.sp, fontWeight = FontWeight.Black)
                    Text("Ride aayi. Ride gayi.\nTeri.", color = Color.White, fontSize = 30.sp,
                        fontWeight = FontWeight.Black, lineHeight = 34.sp)
                }

                // POWER BUTTON
                item {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box(
                            Modifier.size(190.dp).clip(CircleShape)
                                .background(if (on) NEON else CARD)
                                .border(3.dp, if (on) NEON else Color(0xFF333333), CircleShape)
                                .clickable {
                                    if (!svcOn) {
                                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                    } else {
                                        Cfg.enabled = !Cfg.enabled; Cfg.save()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(if (on) "ON" else "OFF", fontSize = 46.sp, fontWeight = FontWeight.Black,
                                    color = if (on) Color.Black else Color.White)
                                Text(
                                    if (!svcOn) "pehle service allow karo" else if (on) "ride pakad raha hai" else "tap = start",
                                    fontSize = 12.sp, color = if (on) Color.Black else DIM
                                )
                            }
                        }
                    }
                }

                // STATS
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        StatBox("PAKDI", Stats.nAcc.toString(), NEON, Modifier.weight(1f))
                        StatBox("SKIP", Stats.nSkip.toString(), RED, Modifier.weight(1f))
                        StatBox("TOTAL", (Stats.nAcc + Stats.nSkip).toString(), Color.White, Modifier.weight(1f))
                    }
                }

                // FILTERS
                item {
                    Card2 {
                        Text("FILTER", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Knob("Min drop distance", Cfg.minDrop, 0f..40f, "km") { Cfg.minDrop = it; Cfg.save() }
                        Knob("Max pickup distance", Cfg.maxPickup, 0.5f..10f, "km") { Cfg.maxPickup = it; Cfg.save() }
                        Knob("Min fare (base + bonus)", Cfg.minFare, 0f..500f, "₹") { Cfg.minFare = it; Cfg.save() }
                        Knob("Min ₹ per km", Cfg.minPerKm, 0f..15f, "₹/km") { Cfg.minPerKm = it; Cfg.save() }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Parcel rides bhi lo", color = Color.White, modifier = Modifier.weight(1f))
                            Switch(Cfg.allowParcel, { Cfg.allowParcel = it; Cfg.save() })
                        }
                    }
                }

                // DEBUG
                item {
                    Card2 {
                        Text("DEBUG", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("Screen dump mode\n(Rapido kholke ride card aane do)", color = Color.White,
                                fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Switch(Cfg.dump, { Cfg.dump = it; Cfg.save() })
                        }
                        Button(onClick = {
                            val cm = ctx.getSystemService(ClipboardManager::class.java)
                            cm.setPrimaryClip(ClipData.newPlainText("dump", Cfg.lastDump))
                            Toast.makeText(ctx, if (Cfg.lastDump.isEmpty()) "Dump khali hai" else "Dump copy ho gaya",
                                Toast.LENGTH_SHORT).show()
                        }, colors = ButtonDefaults.buttonColors(containerColor = NEON, contentColor = Color.Black)) {
                            Text("DUMP COPY KARO", fontWeight = FontWeight.Black)
                        }
                        TextButton(onClick = { Stats.reset() }) { Text("Log reset", color = DIM) }
                    }
                }

                item { Text("LIVE LOG", color = NEON, fontSize = 12.sp, fontWeight = FontWeight.Black) }
                items(Stats.lines) {
                    Text(it, color = if (it.startsWith("⚡")) NEON else if (it.startsWith("✗")) RED else DIM,
                        fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun Card2(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CARD).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable
fun StatBox(label: String, value: String, color: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(CARD).padding(14.dp)) {
        Text(value, color = color, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text(label, color = DIM, fontSize = 11.sp)
    }
}

@Composable
fun Knob(title: String, value: Float, range: ClosedFloatingPointRange<Float>, unit: String, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(title, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text("%.1f %s".format(value, unit), color = NEON, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        Slider(value = value, onValueChange = { onChange(Math.round(it * 2f) / 2f) }, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = NEON, activeTrackColor = NEON))
    }
}
